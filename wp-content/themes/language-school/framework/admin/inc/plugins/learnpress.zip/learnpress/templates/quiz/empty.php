<?php

?>
<?php do_action( 'learn_press_before_quiz_questions_empty_element' );?>
<div class="lp-quiz-questions-empty">
    <?php do_action( 'learn_press_begin_quiz_questions_empty_element' );?>
    <p><?php _e( 'No question found!', 'learn_press' );?></p>
    <?php do_action( 'learn_press_end_quiz_questions_empty_element' );?>
</div>
<?php do_action( 'learn_press_after_quiz_questions_empty_element' );?>