<?php 

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function course_page_summary_shortcode() {
	
}

add_shortcode( 'learn_press_course_summary', 'course_page_summary_shortcode' );