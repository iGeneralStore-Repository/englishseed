<?php
/**
 * Created by PhpStorm.
 * User: foobla
 * Date: 3/18/2015
 * Time: 11:35 AM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>