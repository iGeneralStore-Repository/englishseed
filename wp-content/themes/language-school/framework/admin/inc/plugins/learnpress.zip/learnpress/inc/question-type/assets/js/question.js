/**
 * Created by Tu on 30/03/2015.
 */

;(function($){

})(jQuery);