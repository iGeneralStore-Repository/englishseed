<?php if( !learn_press_get_quiz_questions() ){?>
<p class="no-question"><?php _e( 'No question in this quiz', 'learn_press' );?></p>
<?php }?>